const $ = (s) => document.querySelector(s);
const send = (m) => chrome.runtime.sendMessage(m);
const ORDER = [1, 2, 3, 4, 5, 6, 0];
const NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
let st = { schedules: [], allowlist: [], session: null, settings: FG.mergeSettings() };
let pick = [1, 2, 3, 4, 5];

const dayText = (d) => {
  const s = [...d].sort().join();
  if (s === "1,2,3,4,5") return "Weekdays";
  if (d.length === 7) return "Every day";
  return ORDER.filter((n) => d.includes(n)).map((n) => NAMES[n]).join(", ");
};
const showErr = (el, m) => { el.textContent = m || ""; el.classList.toggle("hidden", !m); };

async function refresh() {
  const s = await chrome.storage.local.get(["schedules", "allowlist", "session", "settings"]);
  st = { schedules: s.schedules || [], allowlist: s.allowlist || [], session: s.session || null, settings: FG.mergeSettings(s.settings) };
  render();
}

function render() {
  $("#dayPick").replaceChildren(...ORDER.map((n) => FG.h("button", { class: "day" + (pick.includes(n) ? " on" : ""), dataset: { d: n } }, NAMES[n])));
  $("#schedList").replaceChildren(...(st.schedules.length
    ? st.schedules.map((x) => FG.h("li", {},
        FG.h("div", { class: "grow" }, FG.h("b", {}, x.name || "Focus"), FG.h("span", {}, `${dayText(x.days)} · ${x.start} – ${x.end}`)),
        FG.h("label", { class: "switch" }, FG.h("input", { type: "checkbox", checked: !!x.enabled, dataset: { t: x.id } }), " On"),
        FG.h("button", { class: "x", dataset: { del: x.id } }, "Delete")))
    : [FG.h("li", { class: "empty" }, "No schedules yet. Add one below to block sites automatically.")]));
  const locked = st.session && st.session.phase === "work";
  $("#allowList").replaceChildren(...(st.allowlist.length
    ? st.allowlist.map((a) => FG.h("li", {}, FG.h("div", { class: "grow" }, FG.h("span", {}, a)), FG.h("button", { class: "x", dataset: { rm: a }, disabled: !!locked }, "Remove")))
    : [FG.h("li", { class: "empty" }, "No allowed pages. Everything on your block list stays blocked.")]));
  const p = st.settings.pomodoro;
  if (document.activeElement && document.activeElement.tagName === "INPUT" && document.activeElement.closest(".fields")) return;
  $("#fWork").value = p.work; $("#fBreak").value = p.break; $("#fLong").value = p.longBreak; $("#fRounds").value = p.rounds;
  $("#fGoal").value = st.settings.dailyGoalMin; $("#fPer").value = st.settings.minutesPerBlock;
}

async function saveSchedules(list, errEl = $("#schErr")) {
  const r = await send({ type: "saveSchedules", schedules: list });
  showErr(errEl, r && !r.ok ? r.error : "");
  return r && r.ok;
}

$("#dayPick").onclick = (e) => {
  const b = e.target.closest("[data-d]"); if (!b) return;
  const n = +b.dataset.d;
  pick = pick.includes(n) ? pick.filter((x) => x !== n) : [...pick, n];
  render();
};
$("#schAdd").onclick = async () => {
  const item = { id: String(Date.now()), name: $("#schName").value, days: pick, start: $("#schStart").value, end: $("#schEnd").value, enabled: true };
  if (await saveSchedules([...st.schedules, item])) $("#schName").value = "";
};
$("#schedList").onclick = (e) => {
  const b = e.target.closest("[data-del]"); if (b) saveSchedules(st.schedules.filter((x) => x.id !== b.dataset.del));
};
$("#schedList").onchange = (e) => {
  const c = e.target.closest("[data-t]"); if (!c) return;
  saveSchedules(st.schedules.map((x) => (x.id === c.dataset.t ? { ...x, enabled: c.checked } : x)));
};

async function addAllow() {
  const v = $("#allowInput").value; if (!v.trim()) return;
  const r = await send({ type: "addAllow", page: v });
  if (r && r.ok) $("#allowInput").value = "";
  showErr($("#allowErr"), r && !r.ok ? r.error : "");
}
$("#allowAdd").onclick = addAllow;
$("#allowInput").onkeydown = (e) => { if (e.key === "Enter") addAllow(); };
$("#allowList").onclick = async (e) => {
  const b = e.target.closest("[data-rm]"); if (!b || b.disabled) return;
  const r = await send({ type: "removeAllow", page: b.dataset.rm });
  showErr($("#allowErr"), r && !r.ok ? r.error : "");
};

$("#save").onclick = async () => {
  const r = await send({ type: "saveSettings", settings: {
    dailyGoalMin: $("#fGoal").value, minutesPerBlock: $("#fPer").value,
    pomodoro: { work: $("#fWork").value, break: $("#fBreak").value, longBreak: $("#fLong").value, rounds: $("#fRounds").value },
  } });
  if (r && r.ok) { $("#saved").classList.remove("hidden"); setTimeout(() => $("#saved").classList.add("hidden"), 2000); await refresh(); }
};

$("#ver").textContent = chrome.runtime.getManifest().version;
chrome.storage.onChanged.addListener(refresh);
refresh();
