const $ = (s) => document.querySelector(s);
const key = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const fmt = (min) => { min = Math.round(min); return min < 60 ? `${min}m` : `${Math.floor(min / 60)}h ${String(min % 60).padStart(2, "0")}m`; };

async function render() {
  const s = await chrome.storage.local.get(["stats", "settings"]);
  const stats = s.stats || {};
  const cfg = FG.mergeSettings(s.settings);
  const per = cfg.minutesPerBlock, goal = cfg.dailyGoalMin;
  const sk = FG.calcStreak(stats, goal);
  $("#kStreak").textContent = `${sk.current} day${sk.current === 1 ? "" : "s"}`;
  $("#kBest").textContent = `Best: ${sk.best} day${sk.best === 1 ? "" : "s"}`;
  const today = stats[key(new Date())] || { focusMs: 0, sessions: 0, blocked: 0, sites: {} };
  const focus = today.focusMs / 60000, saved = today.blocked * per;

  $("#date").textContent = new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });
  $("#headline").textContent = focus || today.blocked
    ? `You focused for ${fmt(focus)} and saved about ${fmt(saved)} today.`
    : "No focus sessions yet today. Start one from the extension icon.";
  $("#kFocus").textContent = fmt(focus);
  $("#kSessions").textContent = today.sessions;
  $("#kBlocked").textContent = today.blocked;
  $("#kSaved").textContent = fmt(saved);
  $("#per").value = per;

  // 7-day chart
  const days = [];
  for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d); }
  const vals = days.map((d) => Math.round(((stats[key(d)] || {}).focusMs || 0) / 60000));
  const max = Math.max(30, goal, ...vals);
  $("#weekTotal").textContent = `${fmt(vals.reduce((a, b) => a + b, 0))} focused this week`;
  $("#chart").replaceChildren(...days.map((d, i) => FG.h("div", { class: "col" + (i === 6 ? " today" : "") + (vals[i] >= goal ? " met" : "") },
    FG.h("span", { class: "v" }, vals[i] ? fmt(vals[i]) : ""),
    FG.h("div", { class: "bar", style: `height:${(vals[i] / max) * 130}px`, title: `${d.toLocaleDateString()}: ${fmt(vals[i])}` }),
    FG.h("small", {}, d.toLocaleDateString(undefined, { weekday: "short" })))));

  // top sites
  const sites = Object.entries(today.sites || {}).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const top = sites[0] ? sites[0][1] : 1;
  $("#top").replaceChildren(...(sites.length
    ? sites.map(([d, n]) => FG.h("li", {}, FG.h("span", {}, d), FG.h("b", {}, String(n)), FG.h("div", { class: "meter" }, FG.h("i", { style: `width:${(n / top) * 100}%` }))))
    : [FG.h("li", { class: "empty" }, "Nothing blocked yet today. Nice and quiet.")]));
}

$("#per").onchange = (e) => chrome.runtime.sendMessage({ type: "setMinutesPerBlock", value: e.target.value });
chrome.storage.onChanged.addListener(render);
render();
