document.querySelector("#openSettings").onclick = () => chrome.runtime.openOptionsPage();
