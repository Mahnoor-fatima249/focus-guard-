const $ = (s) => document.querySelector(s);
const CIRC = 2 * Math.PI * 54;
const PRESETS = [15, 25, 45, 60, 90];
let st = { blocklist: [], session: null, stats: {}, settings: FG.mergeSettings() };
let mode = "timer", minutes = 25, stopArmed = null;

const dayKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const send = (m) => chrome.runtime.sendMessage(m);

function fmtClock(ms) {
  const t = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
  const p = (n) => String(n).padStart(2, "0");
  return h ? `${h}:${p(m)}:${p(s)}` : `${p(m)}:${p(s)}`;
}
function fmtMin(min) {
  min = Math.round(min);
  if (min < 60) return `${min}m`;
  return `${Math.floor(min / 60)}h ${String(min % 60).padStart(2, "0")}m`;
}

async function refresh() {
  const s = await chrome.storage.local.get(["blocklist", "session", "stats", "settings"]);
  st = {
    blocklist: s.blocklist ?? [],
    session: s.session ?? null,
    stats: s.stats ?? {},
    settings: FG.mergeSettings(s.settings),
  };
  render();
}

function render() {
  const s = st.session;
  $("#setup").classList.toggle("hidden", !!s);
  $("#active").classList.toggle("hidden", !s);
  $("#lockNote").classList.toggle("hidden", !(s && s.phase === "work"));

  // presets + mode
  $("#modeTimer").classList.toggle("on", mode === "timer");
  $("#modePomo").classList.toggle("on", mode === "pomodoro");
  $("#timerOpts").classList.toggle("hidden", mode !== "timer");
  $("#pomoNote").classList.toggle("hidden", mode !== "pomodoro");
  const P = st.settings.pomodoro;
  $("#pomoNote").textContent = `${P.work} minutes of focus, then a ${P.break} minute break. After every ${P.rounds} rounds you get a ${P.longBreak} minute break. Change these in Settings.`;
  $("#presets").replaceChildren(...PRESETS.map((m) => FG.h("button", { class: "preset" + (m === minutes ? " on" : ""), dataset: { m } }, String(m))));

  // blocklist
  const locked = s && s.phase === "work";
  $("#count").textContent = `${st.blocklist.length} site${st.blocklist.length === 1 ? "" : "s"}`;
  $("#chips").replaceChildren(...(st.blocklist.length
    ? st.blocklist.map((d) => FG.h("li", {}, d, FG.h("button", { dataset: { site: d }, disabled: !!locked, "aria-label": `Remove ${d}`, title: locked ? "Locked during focus" : "Remove" }, "×")))
    : [FG.h("li", { class: "empty-li" }, "No sites yet. Add one above.")]));

  // stats
  const e = st.stats[dayKey()] || { focusMs: 0, blocked: 0 };
  $("#sFocus").textContent = fmtMin(e.focusMs / 60000);
  $("#sBlocked").textContent = e.blocked;
  $("#sSaved").textContent = fmtMin(e.blocked * st.settings.minutesPerBlock);

  if (s) {
    const brk = s.phase === "break";
    $("#chip").textContent = brk ? (s.long ? "Long break" : "Break") : "Focus";
    $("#chip").className = "chip " + (brk ? "break" : "work");
    $("#arc").classList.toggle("break", brk);
    $("#sub").textContent = s.mode === "pomodoro" ? `Round ${s.cycle}` : s.mode === "schedule" ? "Scheduled" : `${st.blocklist.length} sites blocked`;
    $("#taskLine").textContent = s.task ? (s.mode === "schedule" ? s.task : `Working on: ${s.task}`) : "";
    $("#taskLine").classList.toggle("hidden", !s.task);
    $("#activeNote").textContent = brk
      ? "Enjoy your break. Blocking resumes automatically when the next round starts."
      : s.mode === "schedule"
      ? "Your scheduled focus window is running. Sites unblock when it ends."
      : s.mode === "pomodoro"
      ? "Pomodoro is running. Focus until the timer ends, then take a short break."
      : "Distracting sites are blocked until the timer ends.";
  } else {
    $("#chip").textContent = "Ready";
    $("#chip").className = "chip";
    $("#arc").classList.remove("break");
    $("#sub").textContent = mode === "pomodoro" ? `${st.settings.pomodoro.work} / ${st.settings.pomodoro.break} min` : "";
  }
  const sk = FG.calcStreak(st.stats, st.settings.dailyGoalMin).current;
  $("#streak").textContent = sk ? `🔥 ${sk}-day streak${[3, 7, 14, 30, 60, 100].includes(sk) ? "!" : ""}` : "No streak yet";
  $("#streak").className = "streak" + (sk ? "" : " none");
  $("#streak").title = `A day counts when you focus for ${st.settings.dailyGoalMin}+ minutes`;
  tick();
}

function tick() {
  const s = st.session;
  let remain, total;
  if (s) { remain = s.endsAt - Date.now(); total = s.totalMin * 60000; }
  else { total = (mode === "pomodoro" ? st.settings.pomodoro.work : minutes) * 60000; remain = total; }
  $("#time").textContent = fmtClock(remain);
  const frac = Math.min(1, Math.max(0, remain / total));
  $("#arc").style.strokeDasharray = CIRC;
  $("#arc").style.strokeDashoffset = CIRC * (1 - frac);
}

function showErr(msg) { const el = $("#err"); el.textContent = msg || ""; el.classList.toggle("hidden", !msg); }

async function addSite() {
  const v = $("#siteInput").value;
  if (!v.trim()) return;
  const r = await send({ type: "addSite", site: v });
  if (r && r.ok) { $("#siteInput").value = ""; showErr(""); } else showErr(r?.error || "Could not add site");
}

$("#modeTimer").onclick = () => { mode = "timer"; render(); };
$("#modePomo").onclick = () => { mode = "pomodoro"; render(); };
$("#presets").onclick = (e) => {
  const b = e.target.closest("[data-m]"); if (!b) return;
  minutes = +b.dataset.m; $("#custom").value = minutes; render();
};
$("#custom").oninput = (e) => { minutes = Math.min(240, Math.max(1, +e.target.value || 1)); render(); };
$("#start").onclick = async () => {
  const r = await send({ type: "start", mode, minutes, task: $("#task").value });
  if (r && !r.ok) showErr(r.error);
};
$("#stop").onclick = async () => {
  const btn = $("#stop");
  if (!stopArmed) {
    btn.textContent = "Tap again to confirm"; btn.classList.add("confirm");
    stopArmed = setTimeout(() => { stopArmed = null; btn.textContent = "End session"; btn.classList.remove("confirm"); }, 3000);
    return;
  }
  clearTimeout(stopArmed); stopArmed = null;
  btn.textContent = "End session"; btn.classList.remove("confirm");
  await send({ type: "stop" });
};
$("#addBtn").onclick = addSite;
$("#siteInput").onkeydown = (e) => { if (e.key === "Enter") addSite(); };
$("#chips").onclick = async (e) => {
  const b = e.target.closest("[data-site]"); if (!b || b.disabled) return;
  const r = await send({ type: "removeSite", site: b.dataset.site });
  if (r && !r.ok) showErr(r.error);
};
$("#openSettings").onclick = () => chrome.runtime.openOptionsPage();
$("#openReport").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("report.html") });

async function checkPerm() {
  let ok = true;
  try { ok = await chrome.permissions.contains({ origins: ["<all_urls>"] }); } catch (e) {}
  $("#perm").classList.toggle("hidden", ok);
}
$("#grant").onclick = async () => {
  const ok = await chrome.permissions.request({ origins: ["<all_urls>"] });
  if (ok) { await send({ type: "resync" }); checkPerm(); }
};
checkPerm();
chrome.storage.onChanged.addListener(refresh);
setInterval(tick, 500);
refresh();
