// Firefox exposes promise-based APIs on `browser`; Chrome/Edge use `chrome`. Use one name everywhere.
if (typeof browser !== "undefined" && browser.runtime) { try { globalThis.chrome = browser; } catch (e) {} }

// Shared helpers (loaded by pages with <script> and by the service worker with importScripts)
const FG = {
  // Safe DOM builder: text is always inserted as text, never parsed as HTML.
  h(tag, attrs = {}, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === false || v == null) continue;
      if (k === "class") el.className = v;
      else if (k === "dataset") Object.assign(el.dataset, v);
      else if (k === "style") el.style.cssText = v;
      else if (k in el) el[k] = v;
      else el.setAttribute(k, v === true ? "" : v);
    }
    for (const c of kids.flat()) el.append(c instanceof Node ? c : document.createTextNode(String(c)));
    return el;
  },
  DEFAULTS: { minutesPerBlock: 5, dailyGoalMin: 25, pomodoro: { work: 25, break: 5, longBreak: 15, rounds: 4 } },
  mergeSettings(s = {}) {
    const D = FG.DEFAULTS;
    return { ...D, ...s, pomodoro: { ...D.pomodoro, ...(s.pomodoro || {}) } };
  },
  dayKey(d = new Date()) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  },
  fmtMin(min) {
    min = Math.round(min);
    return min < 60 ? `${min}m` : `${Math.floor(min / 60)}h ${String(min % 60).padStart(2, "0")}m`;
  },
  toMin(hhmm) { const [h, m] = String(hhmm).split(":").map(Number); return h * 60 + m; },
  // Returns {schedule, endsAt} if a schedule window is active right now.
  activeWindow(schedules, now = new Date()) {
    const cur = now.getHours() * 60 + now.getMinutes(), day = now.getDay();
    for (const s of schedules || []) {
      if (!s.enabled || !s.days.includes(day)) continue;
      const a = FG.toMin(s.start), b = FG.toMin(s.end);
      if (cur >= a && cur < b) {
        const end = new Date(now); end.setHours(Math.floor(b / 60), b % 60, 0, 0);
        return { schedule: s, endsAt: end.getTime() };
      }
    }
    return null;
  },
  // A day counts toward the streak when focus time reaches the daily goal.
  calcStreak(stats, goalMin, today = new Date()) {
    const need = goalMin * 60000;
    const met = (d) => ((stats[FG.dayKey(d)] || {}).focusMs || 0) >= need;
    let current = 0;
    const d = new Date(today);
    if (!met(d)) d.setDate(d.getDate() - 1);
    while (met(d)) { current++; d.setDate(d.getDate() - 1); }
    let best = 0, run = 0, prev = null;
    for (const k of Object.keys(stats).sort()) {
      if ((stats[k].focusMs || 0) < need) { run = 0; prev = null; continue; }
      const dt = new Date(k + "T00:00:00");
      run = prev && Math.round((dt - prev) / 864e5) === 1 ? run + 1 : 1;
      prev = dt; best = Math.max(best, run);
    }
    return { current, best: Math.max(best, current) };
  },
};
