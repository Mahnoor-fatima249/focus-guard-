const $ = (s) => document.querySelector(s);
const site = new URLSearchParams(location.search).get("site") || "This site";
$("#site").textContent = site;
const quotes = [
  "Your future self will thank you.",
  "One focused hour beats three distracted ones.",
  "The feed will still be there when you're done.",
  "Finish the task, then earn the scroll.",
  "Small sessions, steady progress.",
];
$("#quote").textContent = quotes[Math.floor(Math.random() * quotes.length)];
chrome.runtime.sendMessage({ type: "blocked", site });

let session = null;
const dayKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
async function load() {
  const s = await chrome.storage.local.get(["session", "stats", "settings"]);
  session = s.session || null;
  const t = session && session.task;
  $("#task").textContent = t ? (session.mode === "schedule" ? t : `You're working on: ${t}`) : "";
  $("#task").classList.toggle("hidden", !t);
  const e = (s.stats || {})[dayKey()] || { blocked: 0 };
  const per = (s.settings || {}).minutesPerBlock || 5;
  $("#today").textContent = `Today you've avoided ${e.blocked} distraction${e.blocked === 1 ? "" : "s"} — about ${e.blocked * per} minutes saved.`;
}
function tick() {
  if (!session || session.phase !== "work") { $("#time").textContent = "Done"; $("#label").textContent = "This site is available again."; return; }
  const t = Math.max(0, Math.ceil((session.endsAt - Date.now()) / 1000));
  const p = (n) => String(n).padStart(2, "0");
  $("#time").textContent = t >= 3600 ? `${Math.floor(t / 3600)}:${p(Math.floor((t % 3600) / 60))}:${p(t % 60)}` : `${p(Math.floor(t / 60))}:${p(t % 60)}`;
}
const closeTab = async () => { const t = await chrome.tabs.getCurrent(); if (t) chrome.tabs.remove(t.id); else window.close(); };
$("#close").onclick = closeTab;
$("#back").onclick = () => (history.length > 1 ? history.back() : closeTab());
chrome.storage.onChanged.addListener(load);
load().then(tick);
setInterval(tick, 500);
