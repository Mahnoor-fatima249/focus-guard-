// Focus Guard – service worker (Manifest V3)
// Chrome/Edge load helpers via importScripts; Firefox loads shared.js from manifest "scripts".
if (typeof importScripts === "function") importScripts("shared.js");

// Paste a public feedback form link here (for example a Google Form). It opens after uninstall.
const FEEDBACK_URL = "";

const MILESTONES = {
  3: "Three days in a row. A habit is starting to form.",
  7: "A full week of focus. That is something to be proud of.",
  14: "Two weeks straight. Your future self is grateful.",
  30: "Thirty days. You have built a real habit.",
  60: "Sixty days of showing up. Remarkable.",
  100: "One hundred days. Truly impressive.",
};

const DEFAULT_BLOCKLIST = ["youtube.com", "facebook.com", "instagram.com", "tiktok.com", "x.com", "twitter.com", "reddit.com"];

// Run storage-changing work one task at a time to avoid races.
let queue = Promise.resolve();
const serial = (fn) => { const p = queue.then(fn); queue = p.catch(() => {}); return p; };

async function load() {
  const s = await chrome.storage.local.get(["blocklist", "allowlist", "schedules", "scheduleSkipUntil", "session", "stats", "settings"]);
  return {
    blocklist: s.blocklist ?? DEFAULT_BLOCKLIST,
    allowlist: s.allowlist ?? [],
    schedules: s.schedules ?? [],
    skipUntil: s.scheduleSkipUntil ?? 0,
    session: s.session ?? null,
    stats: s.stats ?? {},
    settings: FG.mergeSettings(s.settings),
  };
}

async function bump(fn) {
  const { stats } = await load();
  const k = FG.dayKey();
  const e = stats[k] || { focusMs: 0, sessions: 0, blocked: 0, sites: {} };
  fn(e);
  stats[k] = e;
  const pruned = {};
  Object.keys(stats).sort().slice(-400).forEach((d) => (pruned[d] = stats[d]));
  await chrome.storage.local.set({ stats: pruned });
}

async function addFocus(start, end, completed) {
  const { settings, stats: before } = await load();
  const k = FG.dayKey();
  const prev = (before[k] || {}).focusMs || 0;
  await bump((e) => { e.focusMs += Math.max(0, end - start); if (completed) e.sessions += 1; });
  const { stats } = await load();
  const now = (stats[k] || {}).focusMs || 0, goal = settings.dailyGoalMin * 60000;
  if (prev < goal && now >= goal) {
    const { current } = FG.calcStreak(stats, settings.dailyGoalMin);
    if (MILESTONES[current]) notify(`${current}-day streak!`, MILESTONES[current]);
    else notify("Daily goal reached", `You focused for ${settings.dailyGoalMin} minutes today. Streak: ${current} day${current === 1 ? "" : "s"}.`);
  }
}

function normalizeDomain(raw) {
  let s = String(raw || "").trim().toLowerCase();
  s = s.replace(/^[a-z]+:\/\//, "").replace(/^www\./, "");
  s = s.split(/[\/?#:]/)[0];
  return /^([a-z0-9-]+\.)+[a-z]{2,}$/.test(s) ? s : null;
}

// Allowed pages need a path, e.g. youtube.com/playlist?list=PL123
function normalizeAllow(raw) {
  let s = String(raw || "").trim().replace(/^[a-z]+:\/\//i, "").replace(/^www\./i, "").replace(/[|*^\s]/g, "");
  const i = s.indexOf("/");
  if (i < 1 || i === s.length - 1) return null;
  const host = s.slice(0, i).toLowerCase();
  if (!/^([a-z0-9-]+\.)+[a-z]{2,}$/.test(host)) return null;
  return host + s.slice(i);
}

const matchesAllow = (url, allowlist) => {
  const u = url.replace(/^[a-z]+:\/\//i, "").replace(/^www\./i, "").toLowerCase();
  return allowlist.some((a) => u.startsWith(a.toLowerCase()));
};

const isWork = (s) => !!s && s.phase === "work";
const isRoundBased = (s) => s.mode === "pomodoro";

async function syncRules() {
  const { blocklist, allowlist, session } = await load();
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  let addRules = [];
  if (isWork(session)) {
    addRules = blocklist.map((d, i) => ({
      id: i + 1, priority: 1,
      action: { type: "redirect", redirect: { extensionPath: `/blocked.html?site=${encodeURIComponent(d)}` } },
      condition: { requestDomains: [d], resourceTypes: ["main_frame"] },
    })).concat(allowlist.map((a, i) => ({
      id: 1000 + i, priority: 2,
      action: { type: "allow" },
      condition: { urlFilter: "||" + a, resourceTypes: ["main_frame"] },
    })));
  }
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: existing.map((r) => r.id), addRules });
}

// Send already-open tabs on blocked sites to the blocked page.
async function bounceOpenTabs() {
  const { blocklist, allowlist, session } = await load();
  if (!isWork(session)) return;
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (!t.url || !/^https?:/.test(t.url) || matchesAllow(t.url, allowlist)) continue;
    let host;
    try { host = new URL(t.url).hostname.replace(/^www\./, ""); } catch { continue; }
    const hit = blocklist.find((d) => host === d || host.endsWith("." + d));
    if (hit) chrome.tabs.update(t.id, { url: chrome.runtime.getURL("blocked.html") + "?site=" + encodeURIComponent(hit) }).catch(() => {});
  }
}

async function updateBadge() {
  const { session } = await load();
  if (!session) return chrome.action.setBadgeText({ text: "" });
  const mins = Math.max(0, Math.ceil((session.endsAt - Date.now()) / 60000));
  await chrome.action.setBadgeBackgroundColor({ color: session.phase === "work" ? "#0D9488" : "#D97706" });
  await chrome.action.setBadgeTextColor?.({ color: "#FFFFFF" });
  await chrome.action.setBadgeText({ text: String(mins) });
}

function notify(title, message) {
  chrome.notifications.create({ type: "basic", iconUrl: "icons/icon128.png", title, message });
}

async function beginSession(session) {
  await chrome.storage.local.set({ session });
  await chrome.alarms.create("phaseEnd", { when: session.endsAt });
  await syncRules();
  await bounceOpenTabs();
  await updateBadge();
}

async function startSession({ mode, minutes, task }) {
  const { settings, session: current } = await load();
  if (current) throw new Error("A session is already running.");
  const dur = mode === "pomodoro" ? settings.pomodoro.work : Math.min(240, Math.max(1, Math.round(Number(minutes) || 25)));
  const now = Date.now();
  await beginSession({
    mode, phase: "work", phaseStart: now, endsAt: now + dur * 60000, cycle: 1, totalMin: dur,
    task: String(task || "").trim().slice(0, 80),
  });
}

async function checkSchedules() {
  const { session, schedules, skipUntil } = await load();
  if (session || Date.now() < skipUntil) return;
  const w = FG.activeWindow(schedules);
  if (!w) return;
  const now = Date.now();
  const label = w.schedule.name || "Scheduled focus";
  await beginSession({
    mode: "schedule", phase: "work", phaseStart: now, endsAt: w.endsAt, cycle: 1,
    totalMin: Math.max(1, Math.round((w.endsAt - now) / 60000)), task: label,
  });
  notify("Scheduled focus started", `${label} runs until ${new Date(w.endsAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}.`);
}

async function stopSession() {
  const { session } = await load();
  if (!session) return;
  if (isWork(session)) await addFocus(session.phaseStart, Math.min(Date.now(), session.endsAt), false);
  await chrome.alarms.clear("phaseEnd");
  // Ending a scheduled session early keeps it off until that window is over.
  const extra = session.mode === "schedule" ? { scheduleSkipUntil: session.endsAt } : {};
  await chrome.storage.local.set({ session: null, ...extra });
  await syncRules();
  await updateBadge();
}

async function onPhaseEnd() {
  const { session, settings } = await load();
  if (!session) return;
  const now = Date.now();
  if (isWork(session)) await addFocus(session.phaseStart, session.endsAt, true);

  if (!isRoundBased(session)) {
    await chrome.storage.local.set({ session: null });
    notify(session.mode === "schedule" ? "Scheduled focus finished" : "Session complete",
      session.mode === "schedule" ? "Your focus window is over. Sites are unblocked." : `You focused for ${session.totalMin} minutes. Your sites are unblocked.`);
  } else if (isWork(session)) {
    const long = session.cycle % settings.pomodoro.rounds === 0;
    const mins = long ? settings.pomodoro.longBreak : settings.pomodoro.break;
    const next = { ...session, phase: "break", long, phaseStart: now, endsAt: now + mins * 60000, totalMin: mins };
    await chrome.storage.local.set({ session: next });
    await chrome.alarms.create("phaseEnd", { when: next.endsAt });
    notify(long ? "Long break earned" : "Time for a break", `Rest for ${mins} minutes. Blocked sites are available until the next round.`);
  } else {
    const mins = settings.pomodoro.work;
    const next = { ...session, phase: "work", long: false, phaseStart: now, endsAt: now + mins * 60000, totalMin: mins, cycle: session.cycle + 1 };
    await chrome.storage.local.set({ session: next });
    await chrome.alarms.create("phaseEnd", { when: next.endsAt });
    notify("Back to focus", `Round ${next.cycle} starts now. Distracting sites are blocked again.`);
  }
  await syncRules();
  await bounceOpenTabs();
  await updateBadge();
}

async function reconcile() {
  const { session } = await load();
  if (session) {
    if (session.endsAt <= Date.now()) {
      if (!isRoundBased(session)) await onPhaseEnd(); else await stopSession();
    } else {
      await chrome.alarms.create("phaseEnd", { when: session.endsAt });
    }
  }
  await syncRules();
  await updateBadge();
  await checkSchedules();
  await chrome.alarms.create("tick", { periodInMinutes: 1 });
  if (FEEDBACK_URL) chrome.runtime.setUninstallURL(FEEDBACK_URL);
  if (!(await chrome.alarms.get("dailyReport"))) {
    const t = new Date(); t.setHours(20, 0, 0, 0);
    if (t.getTime() < Date.now()) t.setDate(t.getDate() + 1);
    await chrome.alarms.create("dailyReport", { when: t.getTime(), periodInMinutes: 1440 });
  }
}

async function dailyReport() {
  const { stats, settings } = await load();
  const e = stats[FG.dayKey()];
  if (!e || (!e.focusMs && !e.blocked)) return;
  const { current } = FG.calcStreak(stats, settings.dailyGoalMin);
  notify("Your day in focus",
    `${Math.round(e.focusMs / 60000)} min focused · ${e.blocked} distractions blocked · about ${e.blocked * settings.minutesPerBlock} min saved. Streak: ${current} day${current === 1 ? "" : "s"}.`);
}

const clamp = (v, lo, hi, d) => Math.min(hi, Math.max(lo, Math.round(Number(v)) || d));

function cleanSchedules(list) {
  if (!Array.isArray(list) || list.length > 10) throw new Error("You can save up to 10 schedules.");
  return list.map((s) => {
    const days = [...new Set((s.days || []).map(Number).filter((n) => n >= 0 && n <= 6))];
    if (!days.length) throw new Error("Pick at least one day.");
    if (!/^\d\d:\d\d$/.test(s.start) || !/^\d\d:\d\d$/.test(s.end)) throw new Error("Enter a start and end time.");
    if (FG.toMin(s.end) <= FG.toMin(s.start)) throw new Error("End time must be after the start time.");
    return { id: String(s.id || Date.now() + Math.random()), name: String(s.name || "").trim().slice(0, 30), days, start: s.start, end: s.end, enabled: s.enabled !== false };
  });
}

async function handle(msg) {
  switch (msg.type) {
    case "start": await startSession(msg); return { ok: true };
    case "stop": await stopSession(); return { ok: true };
    case "addSite": {
      const d = normalizeDomain(msg.site);
      if (!d) return { ok: false, error: "Enter a valid site, like youtube.com" };
      const { blocklist } = await load();
      if (blocklist.includes(d)) return { ok: false, error: `${d} is already on your list` };
      await chrome.storage.local.set({ blocklist: [...blocklist, d] });
      await syncRules();
      await bounceOpenTabs();
      return { ok: true };
    }
    case "removeSite": {
      const { blocklist, session } = await load();
      if (isWork(session)) return { ok: false, error: "Sites can't be removed during a focus session." };
      await chrome.storage.local.set({ blocklist: blocklist.filter((d) => d !== msg.site) });
      await syncRules();
      return { ok: true };
    }
    case "addAllow": {
      const { allowlist, session } = await load();
      if (isWork(session)) return { ok: false, error: "Allowed pages can't be changed during a focus session." };
      const a = normalizeAllow(msg.page);
      if (!a) return { ok: false, error: "Enter a page with a path, like youtube.com/playlist?list=PL123" };
      if (allowlist.some((x) => x.toLowerCase() === a.toLowerCase())) return { ok: false, error: "That page is already allowed." };
      await chrome.storage.local.set({ allowlist: [...allowlist, a] });
      await syncRules();
      return { ok: true };
    }
    case "removeAllow": {
      const { allowlist, session } = await load();
      if (isWork(session)) return { ok: false, error: "Allowed pages can't be changed during a focus session." };
      await chrome.storage.local.set({ allowlist: allowlist.filter((x) => x !== msg.page) });
      await syncRules();
      return { ok: true };
    }
    case "saveSchedules": {
      await chrome.storage.local.set({ schedules: cleanSchedules(msg.schedules), scheduleSkipUntil: 0 });
      await checkSchedules();
      return { ok: true };
    }
    case "saveSettings": {
      const { settings } = await load();
      const p = msg.settings.pomodoro || {};
      const next = {
        ...settings,
        dailyGoalMin: clamp(msg.settings.dailyGoalMin, 1, 600, 25),
        minutesPerBlock: clamp(msg.settings.minutesPerBlock, 1, 60, 5),
        pomodoro: {
          work: clamp(p.work, 1, 120, 25), break: clamp(p.break, 1, 60, 5),
          longBreak: clamp(p.longBreak, 1, 120, 15), rounds: clamp(p.rounds, 2, 12, 4),
        },
      };
      await chrome.storage.local.set({ settings: next });
      return { ok: true };
    }
    case "resync": await syncRules(); await bounceOpenTabs(); return { ok: true };
    case "setMinutesPerBlock": {
      const { settings } = await load();
      await chrome.storage.local.set({ settings: { ...settings, minutesPerBlock: clamp(msg.value, 1, 60, 5) } });
      return { ok: true };
    }
    case "blocked": {
      const { session } = await load();
      if (!isWork(session)) return { ok: true };
      await bump((e) => { e.blocked += 1; e.sites[msg.site] = (e.sites[msg.site] || 0) + 1; });
      return { ok: true };
    }
    default: return { ok: false, error: "Unknown request" };
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, send) => {
  serial(() => handle(msg)).then(send).catch((e) => send({ ok: false, error: e.message }));
  return true;
});

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "phaseEnd") serial(onPhaseEnd);
  else if (a.name === "tick") serial(async () => { await updateBadge(); await checkSchedules(); });
  else if (a.name === "dailyReport") serial(dailyReport);
});

chrome.runtime.onInstalled.addListener(async (d) => {
  if (d.reason === "install") {
    await chrome.storage.local.set({ blocklist: DEFAULT_BLOCKLIST });
    chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
  }
  serial(reconcile);
});
chrome.permissions?.onAdded?.addListener(() => serial(reconcile));
chrome.runtime.onStartup.addListener(() => serial(reconcile));
